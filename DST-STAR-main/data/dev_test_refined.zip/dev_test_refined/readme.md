data_mwz2.1.json is the original annotations of MULTIWOZ 2.1

dev/test_dials_manually-modified.json are the refined validation set and test set on top of MultiWOZ 2.1

dev/test_dials_manually-modified-v2.json contain the full state, which is in accordance with the format of MULTIWOZ 2.1

slot_meta.json lists all the slots that appear in the validation set and test set

ontology.json summaries all the candidate values for each slot. This ontology is extracted from data_mwz2.1 by traversing all the dialogues

ontology-modified-dev-test.json is extracted from only the refined validation set and test set
